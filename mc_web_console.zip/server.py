import subprocess
import threading
from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

mc_process = None

def start_mc():
    global mc_process

    mc_process = subprocess.Popen(
        ["bash", "run.sh"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )

    def read_output():
        for line in mc_process.stdout:
            socketio.emit("console_output", line)

    threading.Thread(target=read_output, daemon=True).start()

@app.route("/")
def index():
    return render_template("index.html")

@socketio.on("send_command")
def handle_command(data):
    cmd = data + "\n"
    if mc_process and mc_process.stdin:
        mc_process.stdin.write(cmd)
        mc_process.stdin.flush()

if __name__ == "__main__":
    start_mc()
    socketio.run(app, host="0.0.0.0", port=5443)
